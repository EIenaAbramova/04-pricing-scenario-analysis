"""Extract only the 16 case items, never the unrelated hidden business exports."""
from pathlib import Path
import json, csv, math
import openpyxl

root = Path(__file__).resolve().parents[1]
source = root.parent / 'Кейс моделирование ценовых стратегий (1).xlsx'
w = openpyxl.load_workbook(source, data_only=True)
p, o = w.worksheets[1:3]
items=[]
for r in range(4,20):
    a=[c.value for c in p[r]]
    b=[c.value for c in o[r]]
    assert a[0] == b[0] and a[1] == b[1] and a[2] == b[3]
    items.append(dict(sku=a[0],q=a[1],price=a[2],cost=a[3],regular=a[7],promo=a[8],elasticity=b[2],source_revenue=a[4],source_margin=a[5]))
(root/'data/items.json').write_text(json.dumps(items,ensure_ascii=False,indent=2),encoding='utf-8')
with (root/'data/items.csv').open('w',encoding='utf-8-sig',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(items[0])); writer.writeheader();writer.writerows(items)

def calc(x):
    prices=[v for v in [x['regular'],x['promo']] if isinstance(v,(int,float)) and v>0]
    pn=min(prices) if prices else x['price']
    q=x['q']; c=x['cost']; p=x['price']; e=x['elasticity']
    qo=q*max(0,1-e*(pn/p-1))
    md=q*(p-c)
    target=math.ceil(md/(pn-c)) if q and pn>c else (0 if not q else None)
    return dict(**x,new_price=pn,qo=qo,revenue=q*pn,margin=q*(pn-c),opt_revenue=qo*pn,opt_margin=qo*(pn-c),target=target,
                add_p=max(0,target-q) if target is not None else None,add_o=max(0,target-qo) if target is not None else None)
results=[calc(x) for x in items]
summary={k:sum(x[k] for x in results) for k in ['q','qo','source_revenue','source_margin','revenue','margin','opt_revenue','opt_margin','add_p','add_o']}
summary['coverage_skus']=sum(x['regular'] is not None or x['promo'] is not None for x in items)
summary['coverage_revenue']=sum(x['source_revenue'] for x in results if x['regular'] or x['promo'])/summary['source_revenue']
(root/'qa/expected.json').write_text(json.dumps(dict(summary=summary,items=results),ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False,indent=2))
