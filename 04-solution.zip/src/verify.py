"""Finalize native chart zero baselines (not exposed by the builder API) and verify export."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from xml.etree import ElementTree as ET
import json, math
import openpyxl

root=Path(__file__).resolve().parents[1]
path=root/'outputs/04_решение.xlsx'
ns={'c':'http://schemas.openxmlformats.org/drawingml/2006/chart'}
with ZipFile(path) as z:
    entries={n:z.read(n) for n in z.namelist()}
charts=[n for n in entries if '/charts/chart' in n and n.endswith('.xml')]
assert len(charts)==3
for n in charts:
    tree=ET.fromstring(entries[n])
    for scaling in tree.findall('.//c:valAx/c:scaling',ns):
        low=scaling.find('c:min',ns)
        if low is None:
            low=ET.SubElement(scaling,'{'+ns['c']+'}min')
        low.set('val','0')
    entries[n]=ET.tostring(tree,encoding='utf-8',xml_declaration=True)
with ZipFile(path,'w',ZIP_DEFLATED) as z:
    for n,b in entries.items():z.writestr(n,b)
w=openpyxl.load_workbook(path,data_only=True)
f=openpyxl.load_workbook(path,data_only=False)
expected=json.loads((root/'qa/expected.json').read_text(encoding='utf8'))
for name,key in [('Пессимистичный','margin'),('Оптимистичный','opt_margin')]:
    assert math.isclose(w[name]['N22'].value,expected['summary'][key],abs_tol=1e-6)
    for i,x in enumerate(expected['items'],5):
        assert math.isclose(w[name][f'N{i}'].value,x[key],abs_tol=1e-6)
        assert w[name][f'Q{i}'].value==(x['target'] if x['q'] else 'н/д')
        assert math.isclose(w[name][f'R{i}'].value,x['add_p' if name=='Пессимистичный' else 'add_o'],abs_tol=1e-6) if x['q'] else w[name][f'R{i}'].value=='н/д'
assert sum(len(s._charts) for s in f)==3
errors=[(s.title,c.coordinate,c.value) for s in w for row in s for c in row if c.data_type=='e']
assert not errors,errors
report={'export_passed':True,'checked_items':16,'scenarios':2,'charts':3,'chart_zero_baselines':True,'formula_errors':errors}
(root/'qa/export-verification.json').write_text(json.dumps(report,indent=2),encoding='utf8')
print(json.dumps(report))
