import fs from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {Workbook,SpreadsheetFile} from '@oai/artifact-tool';
const root=new URL('../',import.meta.url);
const items=JSON.parse(await fs.readFile(new URL('data/items.json',root),'utf8'));
const expected=JSON.parse(await fs.readFile(new URL('qa/expected.json',root),'utf8'));
const wb=Workbook.create();
const summary=wb.worksheets.add('Сравнение');
const pess=wb.worksheets.add('Пессимистичный');
const opt=wb.worksheets.add('Оптимистичный');
const input=wb.worksheets.add('Исходные данные');
const fmt='#,##0.00;(#,##0.00);"–"';
function style(s,end,cols){s.showGridLines=false;s.getRange(`A1:${cols}${end}`).format.font={name:'Arial',size:10,color:'#202922'};s.getRange(`A1:${cols}${end}`).format.rowHeight=23;s.getRange(`A1:${cols}${end}`).format.columnWidth=17;s.getRange(`A1:A${end}`).format.columnWidth=22;s.tabColor='#49633B';}
function header(s,row,last){s.getRange(`A${row}:${last}${row}`).format={fill:'#354D2C',font:{name:'Arial',size:10,bold:true,color:'#FFFFFF'},wrapText:true,rowHeight:55,verticalAlignment:'center',horizontalAlignment:'center'};}
style(input,24,'J');
input.getRange('A2').values=[['Данные кейса за анализируемый месяц']];input.getRange('A2').format.font.size=14;
input.getRange('A4:J4').values=[['Товар','Объём, шт.','Цена, руб. с НДС','Закупка, руб. с НДС','Регулярная цена конкурента','Промо конкурента','Эластичность (модуль)','ТО исходный, руб.','МД исходный, руб.','Наличие мониторинга']];header(input,4,'J');
input.getRange('A5:J20').values=items.map(x=>[x.sku,x.q,x.price,x.cost,x.regular,x.promo,x.elasticity,x.source_revenue,x.source_margin,x.regular||x.promo?'Есть':'Нет']);
input.getRange('B5:I20').format.font.color='#0000FF';input.getRange('C5:I20').setNumberFormat(fmt);input.getRange('G5:G20').setNumberFormat('0.000');
input.getRange('A22').values=[['Источник: Кейс моделирование ценовых стратегий (1).xlsx, два листа «Итого», строки 4–19.']];
input.getRange('A23').values=[['Нулевые закупки у ТОВАР6 и ТОВАР14 не подтверждают бесплатный товар. Их базовые продажи равны нулю.']];
input.getRange('A24').values=[['Точная дата месяца в задании не указана. Скрытые выгрузки не входят в расчёт кейса.']];
const columns=['Товар','Объём факт, шт.','Цена факт, руб.','Закупка, руб.','Цена конкурента, руб.','Новая цена, руб.','Δ цены, %','Эластичность','Объём прогноз, шт.','ТО факт, руб.','МД факт, руб.','МД факт, %','ТО прогноз, руб.','МД прогноз, руб.','МД прогноз, %','Δ МД, руб.','Целевой объём, шт.','Дополнительно, шт.','Рост к факту, %','Статус'];
for(const [s,elastic] of [[pess,false],[opt,true]]){
 style(s,26,'T');s.getRange('A2').values=[[elastic?'Прогноз с учётом эластичности':'Прогноз при неизменном объёме']];s.getRange('A2').format.font.size=14;
 s.getRange('A4:T4').values=[columns];header(s,4,'T');s.freezePanes.freezeRows(4);s.freezePanes.freezeColumns(1);
 const ir=5;const f=[`='Исходные данные'!A${ir}`,`='Исходные данные'!B${ir}`,`='Исходные данные'!C${ir}`,`='Исходные данные'!D${ir}`,`=IF(AND('Исходные данные'!E5>0,'Исходные данные'!F5>0),MIN('Исходные данные'!E5,'Исходные данные'!F5),IF('Исходные данные'!E5>0,'Исходные данные'!E5,IF('Исходные данные'!F5>0,'Исходные данные'!F5,"нет цены")))`,`=IF(ISNUMBER(E5),E5,C5)`,`=F5/C5-1`,`='Исходные данные'!G5`,elastic?'=B5*MAX(0,1-H5*G5)':'=B5','=B5*C5','=B5*(C5-D5)','=IF(J5=0,"н/д",K5/J5)','=I5*F5','=I5*(F5-D5)','=IF(M5=0,"н/д",N5/M5)','=N5-K5','=IF(B5=0,"н/д",IF(F5<=D5,"недостижимо",ROUNDUP(K5/(F5-D5),0)))','=IF(ISNUMBER(Q5),MAX(0,Q5-I5),"н/д")','=IF(AND(B5>0,ISNUMBER(Q5)),MAX(0,Q5/B5-1),"н/д")','=IF(B5=0,"Нет базовых продаж",IF(ISNUMBER(E5),"Цена конкурента","Цена сохранена"))'];
 s.getRange('A5:T5').formulas=[f];s.getRange('A5:T20').fillDown();s.getRange('B5:S22').setNumberFormat(fmt);
 for(const c of ['G','L','O','S'])s.getRange(`${c}5:${c}22`).setNumberFormat('0.0%');
 s.getRange('A5:E20').format.font.color='#008000';s.getRange('H5:H20').format.font.color='#008000';
 s.getRange('A22').values=[['Итого']];for(const c of ['B','I','J','K','M','N','P','R'])s.getRange(`${c}22`).formulas=[[`=SUM(${c}5:${c}20)`]];
 s.getRange('L22').formulas=[['=K22/J22']];s.getRange('O22').formulas=[['=N22/M22']];s.getRange('A22:T22').format.fill='#E4EBDF';s.getRange('A22:T22').format.font.bold=true;
 s.getRange('T5:T20').format.columnWidth=24;
 s.getRange('A24').values=[['Целевой объём сохраняет МД факт по каждому товару. Это не окупаемость постоянных затрат.']];
 s.getRange('A25').values=[['Без мониторинга сохраняются текущая цена и объём. Прогнозные штуки не округляются. Целевой объём округляется вверх.']];
 s.getRange('A26').values=[['Дополнительно = MAX(0; целевой объём − прогноз). Сумма не допускает компенсации потерь одного товара другим.']];
}
style(summary,51,'K');summary.getRange('A2').values=[['04: сравнение ценовых стратегий']];summary.getRange('A2').format.font.size=14;
summary.getRange('A4:D4').values=[['Показатель','Факт','Пессимистичный','Оптимистичный']];header(summary,4,'D');summary.getRange('A4:A13').format.columnWidth=31;summary.getRange('B4:D13').format.columnWidth=23;
const metrics=[['Товарооборот, руб.','J','M'],['Маржинальный доход, руб.','K','N'],['МД, %','L','O'],['Продажи, шт.','B','I']];
for(let i=0;i<4;i++){let r=5+i;const [name,base,forecast]=metrics[i];summary.getRange(`A${r}`).values=[[name]];summary.getRange(`B${r}:D${r}`).formulas=[[`='Пессимистичный'!${base}22`,`='Пессимистичный'!${forecast}22`,`='Оптимистичный'!${forecast}22`]];}
summary.getRange('A10:A13').values=[['Изменение ТО, %'],['Изменение МД, %'],['Изменение МД, п.п.'],['Изменение объёма, %']];
for(const c of ['C','D'])summary.getRange(`${c}10:${c}13`).formulas=[[`=${c}5/$B$5-1`],[`=${c}6/$B$6-1`],[`=(${c}7-$B$7)*100`],[`=${c}8/$B$8-1`]];
summary.getRange('B5:D13').setNumberFormat(fmt);summary.getRange('B7:D7').setNumberFormat('0.0%');summary.getRange('C10:D11').setNumberFormat('0.0%');summary.getRange('C13:D13').setNumberFormat('0.0%');
summary.getRange('A15:D15').values=[['Сценарий','ТО, руб.','МД, руб.','Продажи, шт.']];header(summary,15,'D');
summary.getRange('A16:A18').values=[['Факт'],['Пессимистичный'],['Оптимистичный']];
for(let i=0;i<3;i++){const c=['B','C','D'][i];summary.getRange(`B${16+i}:D${16+i}`).formulas=[[`=${c}5`,`=${c}6`,`=${c}8`]];}summary.getRange('B16:D18').setNumberFormat(fmt);
// Render the compact results separately because the renderer can mask cells around drawings.
wb.recalculate();
const tablePreview=await wb.render({sheetName:summary.name,range:'A1:D18',scale:2,format:'png'});await fs.writeFile(new URL('qa/summary-table.png',root),new Uint8Array(await tablePreview.arrayBuffer()));
for(const [title,col,start,end] of [['Товарооборот, руб.','B','A21','F34'],['Маржинальный доход, руб.','C','G21','L34'],['Объём продаж, шт.','D','A36','F49']]){
const ch=summary.charts.add('bar',[summary.getRange('A15:A18'),summary.getRange(`${col}15:${col}18`)]);ch.title=title;ch.hasLegend=false;ch.setPosition(start,end);ch.titleTextStyle.typeface='Arial';ch.titleTextStyle.fontSize=12;ch.yAxis={numberFormatCode:'#,##0',numberFormatSourceLinked:false};ch.series.items[0].fill='#64834D';}
summary.getRange('G36').values=[['Вывод']];summary.getRange('G37').values=[['Следование конкуренту снижает МД в обоих сценариях.']];
summary.getRange('G39').values=[['Цены конкурента есть у 8 из 16 товаров.']];summary.getRange('G40').values=[['Они покрывают 79,8% фактического оборота.']];summary.getRange('G42').values=[['Для остальных товаров текущие цены сохранены.']];summary.getRange('G44').values=[['«Оптимистичный» — название из задания, а не гарантия роста МД.']];
summary.getRange('G46').values=[['Закупка неизменна. Все денежные расчёты с НДС, как в кейсе.']];summary.getRange('G48').values=[['МД не является чистой прибылью. Постоянные расходы не заданы.']];
// Verify live reactions before restoring the original input.
const original=input.getRange('F5').values[0][0];const before=pess.getRange('M5').values[0][0];input.getRange('F5').values=[[1400]];const after=pess.getRange('M5').values[0][0];if(before===after)throw Error('Input does not recalculate');input.getRange('F5').values=[[original]];
const pair=input.getRange('E5:F5').values;
input.getRange('E5:F5').values=[[null,1200]];if(pess.getRange('F5').values[0][0]!==1200)throw Error('Promo-only boundary');
input.getRange('E5:F5').values=[[null,null]];if(pess.getRange('F5').values[0][0]!==1449||opt.getRange('I5').values[0][0]!==374)throw Error('Missing monitoring boundary');
input.getRange('E5:F5').values=[[null,1000]];if(pess.getRange('Q5').values[0][0]!=='недостижимо')throw Error('Unattainable target boundary');
input.getRange('E5:F5').values=pair;
wb.recalculate();
const actual=summary.getRange('B5:D8').values;
const ex=expected.summary;const want=[[ex.source_revenue,ex.revenue,ex.opt_revenue],[ex.source_margin,ex.margin,ex.opt_margin],[ex.source_margin/ex.source_revenue,ex.margin/ex.revenue,ex.opt_margin/ex.opt_revenue],[ex.q,ex.q,ex.qo]];
for(let i=0;i<4;i++)for(let j=0;j<3;j++)if(Math.abs(actual[i][j]-want[i][j])>0.00001)throw Error(`Mismatch ${i},${j}: ${actual[i][j]} vs ${want[i][j]}`);
await fs.writeFile(new URL('qa/verification.json',root),JSON.stringify({actual,expected:want,recalculation:{before,after},passed:true},null,2));
console.log((await wb.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#NUM!',options:{useRegex:true,maxResults:20},maxChars:1500})).ndjson);
const out=await SpreadsheetFile.exportXlsx(wb);await out.save(fileURLToPath(new URL('outputs/04_решение.xlsx',root)));
for(const [s,range]of [[summary,'A1:L49'],[pess,'A1:J12'],[pess,'K4:T22'],[opt,'A1:J12'],[opt,'K4:T22'],[input,'A1:J20']]){const preview=await wb.render({sheetName:s.name,range,scale:1.5,format:'png'});await fs.writeFile(new URL(`qa/${s.name}-${range.replace(':','-')}.png`,root),new Uint8Array(await preview.arrayBuffer()));}
console.log(JSON.stringify(actual));
