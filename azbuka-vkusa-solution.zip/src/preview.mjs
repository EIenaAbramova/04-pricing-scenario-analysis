import fs from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {FileBlob,SpreadsheetFile} from '@oai/artifact-tool';
const root=new URL('../',import.meta.url);
const wb=await SpreadsheetFile.importXlsx(await FileBlob.load(fileURLToPath(new URL('outputs/Азбука_вкуса_решение.xlsx',root))));
for (const [name,range,file] of [['Сравнение','A1:D18','summary-final'],['Сравнение','A21:L49','charts-final']]){
const p=await wb.render({sheetName:name,range,scale:1.5,format:'png'});await fs.writeFile(new URL(`qa/${file}.png`,root),new Uint8Array(await p.arrayBuffer()));
}
